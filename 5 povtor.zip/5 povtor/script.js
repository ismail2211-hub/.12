let input = document.getElementById("input");
let ulTO = document.getElementById("ulTO");
let ulFrom = document.getElementById("ulFrom");
let btnFrom = document.getElementById("btnFrom");
let btnTo = document.getElementById("btnTo");
let sentBtn = document.getElementById("sentBtn");

let fromValuta = "USD";
let toValuta = "UZS";


async function ValutchikSanjar(amout , from , to) {

    try{
        let api_key = `cur_live_S1OiRgiIS8ZJOfDmPjgSqmeAarnhxBBg2dhZljEw`
        let url = `https://api.currencyapi.com/v3/latest?apikey=${api_key}&base_currency=${from}`
        const response = await fetch(url)
        const data = await response.json()
        console.log(data.data); 

        
        

    }
}